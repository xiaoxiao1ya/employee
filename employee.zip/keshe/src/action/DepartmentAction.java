package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import dao�ӿ�.iDepartment;
import dao�ӿ�.iEmployee;
import po.Department;
import po.Employee;
//ʵ��ModelDriven�ӿ�
public class DepartmentAction extends ActionSupport implements ModelDriven<Department>{
	private iDepartment idepart;
	private iEmployee iemploy;
	public void setIemploy(iEmployee iemploy) {
		this.iemploy = iemploy;
	}
	//ʵ����һ��department����
	private Department department=new Department();
	public void setIdepart(iDepartment idepart) {
		this.idepart = idepart;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	@Override
	public Department getModel() {
		// TODO Auto-generated method stub
		return department;
	}
	
	public String show(){
//		HttpServletRequest request = ServletActionContext.getRequest();//����request
//		int id=Integer.parseInt(request.getParameter("id"));
//		String s=iemploy.findTypeById(id);
//		request.setAttribute("type", s);
		//��ȡ���в�����Ϣ�ļ���
		List<Department> allDepartment=idepart.findAll();
		ActionContext.getContext().getValueStack().set("alldepartment", allDepartment);
		return "findAllDepartmentSuccess";
	}
	public String showall(){
//		HttpServletRequest request = ServletActionContext.getRequest();//����request
//		int id=Integer.parseInt(request.getParameter("id"));
//		String s=iemploy.findTypeById(id);
//		request.setAttribute("type", s);
		List<Department> allDepartment=idepart.findAll();
		ActionContext.getContext().getValueStack().set("alldepartment", allDepartment);
		return "showAll";
	}
	public String showDepart(){
		HttpServletRequest request = ServletActionContext.getRequest();//����request
		int did=Integer.parseInt(request.getParameter("id"));
		department=idepart.findByDid(did);
		List<Department> allDepartment=idepart.findAll();
		ActionContext.getContext().getValueStack().set("alldepartment", allDepartment);
		return "findAllDepartmentSuccess";
	}
	
	public String add(){
		HttpServletRequest request = ServletActionContext.getRequest();//����request
		HttpServletResponse response=ServletActionContext.getResponse();
		response.setCharacterEncoding("utf-8");
		int id=Integer.parseInt(request.getParameter("id"));
		Employee employ=iemploy.findById(id);
		if(employ.getType().equals("����")){
			return "addD";
		}
//		response.getWriter().write("<script>alert('�㻹û��Ȩ�ޣ�����ϵ����Ա')</script>");
		return "addfail";
	}
	//���Ӳ��ź�ı��沿�ŷ���
	public String addsave(){
//		HttpServletRequest request = ServletActionContext.getRequest();//����request
//		int did=Integer.parseInt(request.getParameter("did"));
		Department d=idepart.findByDid(department.getDid());
		if(d==null){//�ж����ӵĲ��ű���Ƿ��Ѿ�����Ĳ���ʹ��
			idepart.save(department);
			return "saveDSuccess";
		}
		this.addActionError("�ñ���ѱ�"+d.getDname()+"ʹ��");
		return "saveDFail";
	}
	public String edit(){
		HttpServletRequest request = ServletActionContext.getRequest();//����request
		HttpServletResponse response=ServletActionContext.getResponse();
		response.setCharacterEncoding("utf-8");
		int id=Integer.parseInt(request.getParameter("id"));
		Employee employ=iemploy.findById(id);
		if(employ.getType().equals("����")){
			List<Department> allDepartment=idepart.findAll();
			ActionContext.getContext().getValueStack().set("alldepartment", allDepartment);
			return "editDpage";
		}
		return "editDpageFail";
	}
	public String del(){
		HttpServletRequest request = ServletActionContext.getRequest();
		int id=Integer.parseInt(request.getParameter("id"));
		department=idepart.findByDid(id);
		idepart.del(department);
//		return "delsuccess";
		return "updatesavesuccess";
	}
	//��ת���༭���ŵ�ҳ��
	public String update(){
		HttpServletRequest request = ServletActionContext.getRequest();
		int id=Integer.parseInt(request.getParameter("id"));
		//����id���Ҳ�����Ϣ����ʾ�ڱ༭ҳ��
		department=idepart.findByDid(id);
		return "updatesuccess";
	}
	//����Ҫ�༭�Ĳ�����Ϣ�����޸ģ������浽���ݿ�
	public String updatesave(){
		idepart.update(department);
		return "updatesavesuccess";
	}
}