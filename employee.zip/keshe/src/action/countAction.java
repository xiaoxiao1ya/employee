package action;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

import dao�ӿ�.iCount;
import dao�ӿ�.iEmployee;
import po.Employee;


public class countAction extends ActionSupport {
	private iCount icount;
	private iEmployee iemploy;
	public void setIemploy(iEmployee iemploy) {
		this.iemploy = iemploy;
	}
	public void setIcount(iCount icount) {
		this.icount = icount;
	}
	//�Ա�ͳ��
	public String sexCount(){
		List it =icount.employeeSexCount();
		HttpServletRequest request=ServletActionContext.getRequest();//����request
		request.setAttribute("count", it);
		return "CountSuccess";
	}
	//����ͳ��
	public String typeCount(){
		List it =icount.employeeTypeCount();
		HttpServletRequest request=ServletActionContext.getRequest();//����request
		request.setAttribute("count", it);
		return "CountSuccess";
	}
	//��������ͳ��
	public String departCount(){
		List it =icount.departEmployCount();
		HttpServletRequest request=ServletActionContext.getRequest();//����request
		request.setAttribute("count", it);
		return "CountSuccess";
	}
	//����н�ʼ���
	public String money(){
		HttpServletRequest request=ServletActionContext.getRequest();//����request
		int id=Integer.parseInt(request.getParameter("id"));
		List it=icount.employPay(id);
		request.setAttribute("pay", it);
		return "moneySuccess";
	}
	//����Ա��н�ʼ���
	public String employeeMoney(){
		HttpServletRequest request=ServletActionContext.getRequest();//����request
		int id=Integer.parseInt(request.getParameter("id"));
		Employee employ=iemploy.findById(id);
		if(employ.getType().equals("����")){
			List it=icount.employPay();
			request.setAttribute("pay", it);
			return "moneySuccess";
		}
		return "countMoneyFail";
	}
}