package action;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import dao�ӿ�.iEmployee;
import dao�ӿ�.iDepartment;
import po.Department;
import po.Employee;
//ʵ��ModelDriven�ӿ�
public class EmployeeAction extends ActionSupport implements ModelDriven<Employee>{
	//ʵ����һ��employee����
	private Employee employee=new Employee();
	private iEmployee iemploy;
	private iDepartment idepart;
	public void setIdepart(iDepartment idepart) {
		this.idepart = idepart;
	}
	public void setIemploy(iEmployee iemploy) {
		this.iemploy = iemploy;
	}
	@Override
	public Employee getModel() {
		// TODO Auto-generated method stub
		return employee;
	}
	
	public String login(){
		Employee existEmployee=iemploy.findByIdAndPassword(employee);
		if(existEmployee==null){//��¼ʧ��
			this.addActionError("�������󣡣�");
			return "loginFail";
		}
		else{
			//�൱��session
			ActionContext.getContext().getSession().put("existEmployee", existEmployee);
			return "loginSuccess";
		}
	}
	//�ж�Ա�������Ͳ��鿴����Ա������Ϣ
	public String show(){
		HttpServletRequest request = ServletActionContext.getRequest();//����request
		int id=Integer.parseInt(request.getParameter("id"));
		String s=iemploy.findTypeById(id);
		request.setAttribute("type", s);
		List<Employee> allEmployee=iemploy.findAll();
		ActionContext.getContext().getValueStack().set("allEmployee", allEmployee);
		return "findAllEmployeeSuccess";
	}
	//�鿴����Ա������Ϣ
	public String showAll(){
		List<Employee> allemploy=iemploy.findAll();
		ActionContext.getContext().getValueStack().set("allemploy", allemploy);
		return "showAllEmployeeSuccess";
	}
	public String findByIdPage(){
		return "findByIdPage";
	}
	public String findById(){
		HttpServletRequest request = ServletActionContext.getRequest();//����request
		int id=Integer.parseInt(request.getParameter("id"));
		employee=iemploy.findById(id);
		if(employee==null){
			this.addActionError("���޴��ˣ�����");
			return "findByIdFail";
		}
		return "findByIdSuccess";
	}
	public String del(){
		iemploy.delete(employee);
		return "delSuccess";
	}
	public String edit(){
		employee=iemploy.findById(employee.getId());
		List<Department> list =idepart.findAll();
		ActionContext.getContext().getValueStack().set("list", list);
		return "editSuccess";
	}
	public String update(){
		iemploy.update(employee);
		return "updateSuccess";
	}
	public String add(){
		List<Department> list =idepart.findAll();
		ActionContext.getContext().getValueStack().set("listtype", list);
		return "addSuccess";
	}
	public String save(){
		HttpServletRequest request = ServletActionContext.getRequest();//����request
		int id=Integer.parseInt(request.getParameter("id"));
		Employee e=iemploy.findById(id);
		if(e==null){
			iemploy.save(employee);
			return "saveSuccess";
		}
		this.addActionError("���˺��ѱ�ע�ᣡ��");
		List<Department> list =idepart.findAll();
		ActionContext.getContext().getValueStack().set("list", list);
		return "saveFail";
	}
	public String updatePassword(){
		iemploy.update(employee);
		this.addActionError("�����������¼");
		return "updatePSuccess";
	}
}