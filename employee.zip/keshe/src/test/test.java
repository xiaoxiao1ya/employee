package test;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session=util.HibernateSessionFactory.getSession();
		String hql="select sex,count(*) from Employee group by sex";
		Query query=session.createQuery(hql);
		List list=query.list();
		Iterator it=list.iterator();
		while(it.hasNext()){
			Object[] results=(Object[]) it.next();
			System.out.println(results[0]+":"+results[1]);
		}
	}

}
