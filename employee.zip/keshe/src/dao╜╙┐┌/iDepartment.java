package dao�ӿ�;

import java.util.Iterator;
import java.util.List;

import po.Department;

public interface iDepartment {

	List<Department> findAll();

	Department findByDid(int did);

	void save(Department depart);

	void del(Department d);

	void update(Department department);


}
