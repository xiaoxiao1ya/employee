package dao�ӿ�;

import java.util.List;

import po.Employee;

public interface iEmployee {

	List<Employee> findAll();

	Employee findByIdAndPassword(Employee employee);

	String findTypeById(int id);

	Employee findById(int id);

	void update(Employee employee);

	void delete(Employee employee);

	void save(Employee employee);


}
