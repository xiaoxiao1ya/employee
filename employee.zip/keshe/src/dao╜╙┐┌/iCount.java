package dao�ӿ�;

import java.util.Iterator;
import java.util.List;

public interface iCount {

	List employeeSexCount();
//	Iterator employeeSexCount();

	List employeeTypeCount();

	List employPay(int id);

	List employPay();

	List departEmployCount();

}
