package dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;

import dao�ӿ�.iDepartment;
import po.Department;

public class DepartmentDao extends HibernateDaoSupport implements iDepartment{
	
	@Override
	public List<Department> findAll() {
		// TODO Auto-generated method stub
		return (List<Department>) this.getHibernateTemplate().find("from Department");
	}

	@Override
	public Department findByDid(int did) {
		// TODO Auto-generated method stub
		return this.getHibernateTemplate().get(Department.class, did);
	}

	@Override
	public void save(Department depart) {
		// TODO Auto-generated method stub
		getHibernateTemplate().setCheckWriteOperations(false);
		Session session=util.HibernateSessionFactory.getSession();
		Transaction tran=session.beginTransaction();
		session.save(depart);
		tran.commit();
		session.close();
	}

	@Override
	public void del(Department d) {
		// TODO Auto-generated method stub
//		getHibernateTemplate().setCheckWriteOperations(false);
		Session session=util.HibernateSessionFactory.getSession();
		Transaction tran=session.beginTransaction();
		session.delete(d);
		tran.commit();
		session.close();
	}

	@Override
	public void update(Department department) {
		// TODO Auto-generated method stub
//		getHibernateTemplate().setCheckWriteOperations(false);
		Session session=util.HibernateSessionFactory.getSession();
		Transaction tran=session.beginTransaction();
		session.update(department);
		tran.commit();
		session.close();
	}


}
