package dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import dao�ӿ�.iCount;

public class CountDao implements iCount{
	
	@Override
	public List employeeSexCount() {
		// TODO Auto-generated method stub
		Session session=util.HibernateSessionFactory.getSession();
		String hql="select e.sex,count(*) from Employee e group by sex";
		Query query=session.createQuery(hql);
		List list=query.list();
//		Iterator it=list.iterator();
//		return it;
		return list;
	}

	@Override
	public List employeeTypeCount() {
		// TODO Auto-generated method stub
		Session session=util.HibernateSessionFactory.getSession();
		String hql="select e.type,count(*) from Employee e group by type";
		Query query=session.createQuery(hql);
		List list=query.list();
		return list;
//		Iterator it=list.iterator();
//		return it;
	}

	@Override
	public List employPay(int id) {
		// TODO Auto-generated method stub
		Session session=util.HibernateSessionFactory.getSession();
		String hql="select s.employee.name, s.days,s.pay,s.pay*s.days from Salary s where id="+id;
		Query query=session.createQuery(hql);
		List list=query.list();
//		Iterator it=list.iterator();
		return list;
	}

	@Override
	public List employPay() {
		// TODO Auto-generated method stub
		Session session=util.HibernateSessionFactory.getSession();
		String hql="select s.employee.name,s.days,s.pay, s.pay*s.days from Salary s ";
		Query query=session.createQuery(hql);
		List list=query.list();
//		Iterator it=list.iterator();
		return list;
	}

	@Override
	public List departEmployCount() {
		// TODO Auto-generated method stub
		Session session=util.HibernateSessionFactory.getSession();
		String hql="select e.department.dname,count(*) from Employee e group by dno";
		Query query=session.createQuery(hql);
		List list=query.list();
		return list;
	}

}
