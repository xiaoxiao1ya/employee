package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;

import dao�ӿ�.iEmployee;
import po.Employee;

public class employeeDao extends HibernateDaoSupport implements iEmployee{
//	private SessionFactory sessionFactory;
	
	@Override
	public Employee findByIdAndPassword(Employee employee) {
		// TODO Auto-generated method stub
		String hql="from Employee where id=? and password=?";
		List<Employee> list = (List<Employee>)this.getHibernateTemplate().find(hql, employee.getId(),employee.getPassword());
		if(list.size()>0){
			System.out.println("��ѯ���ݿ����и��û�������");
			return list.get(0);
		}
		return null;
	}

	@Override
	public List<Employee> findAll() {
		// TODO Auto-generated method stub
		String hql="from Employee";
		List<Employee> list=(List<Employee>) this.getHibernateTemplate().find(hql);
		return list;
	}

	@Override
	public String findTypeById(int id) {
		// TODO Auto-generated method stub
		Employee e=this.getHibernateTemplate().get(Employee.class, id);
		return e.getType();
	}

	@Override
	public Employee findById(int id) {
		// TODO Auto-generated method stub
		return this.getHibernateTemplate().get(Employee.class, id);
	}

	@Override
	public void update(Employee employee) {
		// TODO Auto-generated method stub
//		getHibernateTemplate().setCheckWriteOperations(false);
		Session session=util.HibernateSessionFactory.getSession();
		Transaction tran=session.beginTransaction();
		session.update(employee);
		tran.commit();
		session.close();
//		this.getHibernateTemplate().update(employee);
	}

	@Override
	public void delete(Employee employee) {
		// TODO Auto-generated method stub
//		getHibernateTemplate().setCheckWriteOperations(false);
		Session session=util.HibernateSessionFactory.getSession();
		Transaction tran=session.beginTransaction();
		session.delete(employee);
		tran.commit();
		session.close();
//		this.getHibernateTemplate().delete(employee);
	}

	@Override
	public void save(Employee employee) {
		// TODO Auto-generated method stub
//		getHibernateTemplate().setCheckWriteOperations(false);
		Session session=util.HibernateSessionFactory.getSession();
		Transaction tran=session.beginTransaction();
		session.save(employee);
		tran.commit();
		session.close();
	}

	

}
